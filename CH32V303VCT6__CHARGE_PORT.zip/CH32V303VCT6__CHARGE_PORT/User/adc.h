#ifndef __ADC_H
#define __ADC_H

#include "ch32v30x.h"

/* Port 1: keep voltage on PA6, move current from PA7 to PC2 to avoid SPI1 MOSI. */
#define ADC_PORT1_VOLTAGE_PORT   GPIOA
#define ADC_PORT1_VOLTAGE_PIN    GPIO_Pin_6
#define ADC_PORT1_VOLTAGE_CH     ADC_Channel_6

#define ADC_PORT1_CURRENT_PORT   GPIOC
#define ADC_PORT1_CURRENT_PIN    GPIO_Pin_2
#define ADC_PORT1_CURRENT_CH     ADC_Channel_12

/* Port 2 */
#define ADC_PORT2_VOLTAGE_PORT   GPIOB
#define ADC_PORT2_VOLTAGE_PIN    GPIO_Pin_0
#define ADC_PORT2_VOLTAGE_CH     ADC_Channel_8

#define ADC_PORT2_CURRENT_PORT   GPIOB
#define ADC_PORT2_CURRENT_PIN    GPIO_Pin_1
#define ADC_PORT2_CURRENT_CH     ADC_Channel_9

/* Port 3 */
#define ADC_PORT3_VOLTAGE_PORT   GPIOC
#define ADC_PORT3_VOLTAGE_PIN    GPIO_Pin_0
#define ADC_PORT3_VOLTAGE_CH     ADC_Channel_10

#define ADC_PORT3_CURRENT_PORT   GPIOC
#define ADC_PORT3_CURRENT_PIN    GPIO_Pin_1
#define ADC_PORT3_CURRENT_CH     ADC_Channel_11

#define VOLTAGE_DIVIDER          10.0f
#define CURRENT_SENSE_RESISTOR   0.01f
#define CURRENT_AMP_GAIN         10.0f
#define ADC_REF_VOLTAGE          3.3f
#define ADC_RESOLUTION           4096.0f

#define VOLTAGE_THRESHOLD        0.1f
#define CURRENT_THRESHOLD        0.01f

void ADC_Init_All(void);
uint16_t ADC_Read_Channel(uint8_t channel);
float ADC_Read_Voltage(uint8_t channel);
void ADC_Update_All(void);

#endif
