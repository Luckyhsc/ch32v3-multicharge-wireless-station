#ifndef __SYS_H
#define __SYS_H	
#include "ch32v30x.h" 

#define SYSTEM_SUPPORT_UCOS		0

void NVIC_Configuration(void);

#endif