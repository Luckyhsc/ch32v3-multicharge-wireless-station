# 三路充电站项目

## 硬件配置

### 充电端口（3路）
| 路数 | 端口名称 | 说明 |
|------|----------|------|
| 第1路 | A+C | A口和C口共用同一个采样电阻，只有一组数据 |
| 第2路 | C | 单C口 |
| 第3路 | WL | 单C口 + 无线充电板 |

### ADC引脚分配（共6个ADC通道）
| 路数 | 功能 | ADC通道 | 引脚 |
|------|------|---------|------|
| 第1路（A+C） | 电压采样 | ADC_IN6 | PA6 |
| 第1路（A+C） | 电流采样 | ADC_IN7 | PA7 |
| 第2路（C） | 电压采样 | ADC_IN8 | PB0 |
| 第2路（C） | 电流采样 | ADC_IN9 | PB1 |
| 第3路（WL） | 电压采样 | ADC_IN10 | PC0 |
| 第3路（WL） | 电流采样 | ADC_IN11 | PC1 |

**注意**：PA0~PA5已被LCD占用（SPI通信），所以ADC使用了PA6~PA7、PB0~PB1、PC0~PC1。

### 按键引脚
| 按键 | 引脚 |
|------|------|
| 左键 | PC6 |
| 右键 | PC7 |

### LCD引脚
请参考 `lcd_init.h` 和 `lcd_init.c`

---

## 如何修改ADC引脚

所有ADC引脚定义都在 `adc.h` 文件中，使用宏定义方便修改：

### 1. 修改引脚
打开 `adc.h`，找到以下定义并修改：

```c
// 第1路：A+C口（共用采样电阻）
#define ADC_PORT1_VOLTAGE_PIN    GPIO_Pin_6   // PA6 - ADC_IN6
#define ADC_PORT1_CURRENT_PIN    GPIO_Pin_7   // PA7 - ADC_IN7
#define ADC_PORT1_VOLTAGE_CH     ADC_Channel_6
#define ADC_PORT1_CURRENT_CH     ADC_Channel_7

// 第2路：单C口
#define ADC_PORT2_VOLTAGE_PIN    GPIO_Pin_0   // PB0 - ADC_IN8
#define ADC_PORT2_CURRENT_PIN    GPIO_Pin_1   // PB1 - ADC_IN9
#define ADC_PORT2_VOLTAGE_CH     ADC_Channel_8
#define ADC_PORT2_CURRENT_CH     ADC_Channel_9

// 第3路：无线充电（WL）
#define ADC_PORT3_VOLTAGE_PIN    GPIO_Pin_0   // PC0 - ADC_IN10
#define ADC_PORT3_CURRENT_PIN    GPIO_Pin_1   // PC1 - ADC_IN11
#define ADC_PORT3_VOLTAGE_CH     ADC_Channel_10
#define ADC_PORT3_CURRENT_CH     ADC_Channel_11
```

**注意**：修改引脚时需要同时修改 `GPIO_Pin_x` 和 `ADC_Channel_x`，确保它们对应同一个物理引脚。

### 2. ADC通道与引脚对应关系
| ADC通道 | 引脚 |
|---------|------|
| ADC_Channel_0 | PA0 |
| ADC_Channel_1 | PA1 |
| ADC_Channel_2 | PA2 |
| ADC_Channel_3 | PA3 |
| ADC_Channel_4 | PA4 |
| ADC_Channel_5 | PA5 |
| ADC_Channel_6 | PA6 |
| ADC_Channel_7 | PA7 |
| ADC_Channel_8 | PB0 |
| ADC_Channel_9 | PB1 |
| ADC_Channel_10 | PC0 |
| ADC_Channel_11 | PC1 |
| ADC_Channel_12 | PC2 |
| ADC_Channel_13 | PC3 |
| ADC_Channel_14 | PC4 |
| ADC_Channel_15 | PC5 |

---

## 如何校准ADC读数

### 1. 电压分压比校准
打开 `adc.h`，修改 `VOLTAGE_DIVIDER`：

```c
#define VOLTAGE_DIVIDER  6.06f
```

**计算方法**：
- 用万用表测量实际输入电压（例如 20V）
- 查看ADC读取的电压值（例如 3.3V）
- 分压比 = 实际电压 / ADC电压 = 20 / 3.3 ≈ 6.06

### 2. 电流采样电阻校准
打开 `adc.h`，修改 `CURRENT_SENSE_RESISTOR`：

```c
#define CURRENT_SENSE_RESISTOR  0.01f  // 单位：欧姆
```

根据你的实际采样电阻值修改（常见值：0.01Ω、0.05Ω、0.1Ω）。

### 3. 电流放大倍数校准
打开 `adc.h`，修改 `CURRENT_AMP_GAIN`：

```c
#define CURRENT_AMP_GAIN  10.0f
```

如果你的电路中有运放放大电流信号，修改为实际放大倍数。如果没有放大，设置为 `1.0f`。

### 4. ADC参考电压校准
打开 `adc.h`，修改 `ADC_REF_VOLTAGE`：

```c
#define ADC_REF_VOLTAGE  3.3f
```

通常设置为3.3V，如果你的参考电压不同，请修改此值。

---

## 校准步骤

1. **电压校准**：
   - 用万用表测量实际输入电压
   - 通过串口打印ADC读取的原始值
   - 调整 `VOLTAGE_DIVIDER` 直到显示值与万用表一致

2. **电流校准**：
   - 用万用表串联测量实际电流
   - 通过串口打印ADC读取的原始值
   - 调整 `CURRENT_SENSE_RESISTOR` 或 `CURRENT_AMP_GAIN` 直到显示值与实际一致

3. **功率验证**：
   - 功率 = 电压 × 电流
   - 确认功率显示是否正确

---

## 文件说明

| 文件 | 说明 |
|------|------|
| `adc.h` / `adc.c` | ADC采集模块，包含引脚定义、校准参数、采集函数 |
| `charge_port.h` / `charge_port.c` | 充电端口管理，包含LCD显示逻辑 |
| `main.c` | 主程序，初始化并循环调用采集和显示 |
| `lcd.h` / `lcd.c` | LCD驱动 |
| `lcd_init.h` / `lcd_init.c` | LCD初始化 |

---

## 主循环流程

```
while(1)
{
    Key_Scan();          // 按键扫描
    ADC_Update_All();    // 更新ADC采集数据（自动关联到LCD显示）
    ChargePort_Display(); // 刷新LCD显示
    Delay_Ms(50);        // 延时50ms
}
```

ADC采集的数据会自动更新到 `g_charge_ports[]` 全局数组，LCD显示会自动读取这些数据。