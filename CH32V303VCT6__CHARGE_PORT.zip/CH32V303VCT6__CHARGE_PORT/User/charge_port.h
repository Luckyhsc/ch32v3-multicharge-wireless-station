#ifndef __CHARGE_PORT_H
#define __CHARGE_PORT_H

#include "ch32v30x.h"

// 按键引脚定义（后续可修改）
#define KEY_LEFT_PORT       GPIOC
#define KEY_LEFT_PIN        GPIO_Pin_6
#define KEY_RIGHT_PORT      GPIOC
#define KEY_RIGHT_PIN       GPIO_Pin_7

#define KEY_LEFT_READ()     GPIO_ReadInputDataBit(KEY_LEFT_PORT, KEY_LEFT_PIN)
#define KEY_RIGHT_READ()    GPIO_ReadInputDataBit(KEY_RIGHT_PORT, KEY_RIGHT_PIN)

// 长按检测时间（毫秒）
#define LONG_PRESS_TIME     1000

// 充电协议类型
typedef enum {
    PROTOCOL_NONE = 0,
    PROTOCOL_QC20,
    PROTOCOL_QC30,
    PROTOCOL_PD,
    PROTOCOL_AFC,
    PROTOCOL_FCP,
    PROTOCOL_WIRELESS  // 无线充电
} Protocol_t;

// 充电口类型
typedef enum {
    PORT_TYPE_A = 0,
    PORT_TYPE_C,
    PORT_TYPE_WIRELESS
} PortType_t;

// 充电口状态结构体
typedef struct {
    char name[16];           // 接口名称
    uint8_t is_charging;     // 是否正在充电 0=否 1=是
    float voltage;           // 工作电压 (V)
    float current;           // 工作电流 (A)
    float power;             // 工作功率 (W)
    Protocol_t protocol;     // 使用的协议
    PortType_t port_type;    // 接口类型
} ChargePort_t;

// 全局充电口数组（3路）
extern ChargePort_t g_charge_ports[3];
extern uint8_t g_port_count;

// 页面状态
typedef enum {
    PAGE_MAIN = 0,
    PAGE_DETAIL
} Page_t;

extern Page_t g_current_page;
extern int8_t g_selected_index;    // -1表示未选中，0-6表示选中的接口索引

// 函数声明
void ChargePort_Init(void);
void ChargePort_Update(void);
void ChargePort_Display(void);
void Key_Init(void);
void Key_Scan(void);

#endif