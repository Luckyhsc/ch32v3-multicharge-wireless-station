#include "adc.h"
#include "charge_port.h"
#include "debug.h"

// 滤波参数
#define ADC_FILTER_COUNT  10  // 滑动平均滤波次数

// ADC原始值缓存（用于滤波）
static uint16_t s_adc_buffer[6][ADC_FILTER_COUNT] = {0};
static uint8_t s_adc_buffer_index[6] = {0};

// 初始化ADC
void ADC_Init_All(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
    
    // 使能时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | 
                           RCC_APB2Periph_GPIOC | RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);  // ADC时钟 = 72MHz/8 = 9MHz
    
    // 第1路电压：PA6
    GPIO_InitStructure.GPIO_Pin = ADC_PORT1_VOLTAGE_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(ADC_PORT1_VOLTAGE_PORT, &GPIO_InitStructure);

    // 第1路电流：PC2，避开 SPI1 的 PA7(MOSI)
    GPIO_InitStructure.GPIO_Pin = ADC_PORT1_CURRENT_PIN;
    GPIO_Init(ADC_PORT1_CURRENT_PORT, &GPIO_InitStructure);
    
    // 配置PB0~PB1为模拟输入（第2路）
    GPIO_InitStructure.GPIO_Pin = ADC_PORT2_VOLTAGE_PIN | ADC_PORT2_CURRENT_PIN;
    GPIO_Init(ADC_PORT2_VOLTAGE_PORT, &GPIO_InitStructure);
    
    // 配置PC0~PC1为模拟输入（第3路）
    GPIO_InitStructure.GPIO_Pin = ADC_PORT3_VOLTAGE_PIN | ADC_PORT3_CURRENT_PIN;
    GPIO_Init(ADC_PORT3_VOLTAGE_PORT, &GPIO_InitStructure);
    
    // ADC1配置
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    
    // 使能ADC1
    ADC_Cmd(ADC1, ENABLE);
    
    // ADC校准
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
}

// 读取单个ADC通道原始值
uint16_t ADC_Read_Channel(uint8_t channel)
{
    ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_239Cycles5);
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
    return ADC_GetConversionValue(ADC1);
}

// 将ADC原始值转换为电压值（单位：V）
float ADC_Read_Voltage(uint8_t channel)
{
    uint16_t adc_value = ADC_Read_Channel(channel);
    return (float)adc_value / ADC_RESOLUTION * ADC_REF_VOLTAGE;
}

// 滑动平均滤波
static uint16_t ADC_Filter(uint8_t channel_index, uint16_t new_value)
{
    uint32_t sum = 0;
    uint8_t i;
    
    s_adc_buffer[channel_index][s_adc_buffer_index[channel_index]] = new_value;
    s_adc_buffer_index[channel_index]++;
    if(s_adc_buffer_index[channel_index] >= ADC_FILTER_COUNT)
    {
        s_adc_buffer_index[channel_index] = 0;
    }
    
    for(i = 0; i < ADC_FILTER_COUNT; i++)
    {
        sum += s_adc_buffer[channel_index][i];
    }
    
    return (uint16_t)(sum / ADC_FILTER_COUNT);
}

// 更新所有ADC数据并关联到LCD显示
void ADC_Update_All(void)
{
    uint16_t adc_raw;
    float voltage_adc, current_adc;
    float actual_voltage, actual_current, actual_power;
    
    // 第1路：A+C口
    adc_raw = ADC_Read_Channel(ADC_PORT1_VOLTAGE_CH);
    adc_raw = ADC_Filter(0, adc_raw);
    voltage_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_voltage = voltage_adc * VOLTAGE_DIVIDER;
    
    adc_raw = ADC_Read_Channel(ADC_PORT1_CURRENT_CH);
    adc_raw = ADC_Filter(1, adc_raw);
    current_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_current = current_adc / (CURRENT_SENSE_RESISTOR * CURRENT_AMP_GAIN);
    
    actual_power = actual_voltage * actual_current;
    
    // 判断是否充电（电压大于阈值就显示，电流单独判断）
    if(actual_voltage > VOLTAGE_THRESHOLD)
    {
        g_charge_ports[0].is_charging = (actual_current > CURRENT_THRESHOLD) ? 1 : 0;
        g_charge_ports[0].voltage = actual_voltage;
        g_charge_ports[0].current = actual_current;
        g_charge_ports[0].power = actual_power;
    }
    else
    {
        g_charge_ports[0].is_charging = 0;
        g_charge_ports[0].voltage = 0;
        g_charge_ports[0].current = 0;
        g_charge_ports[0].power = 0;
    }
    
    // 第2路：单C口
    adc_raw = ADC_Read_Channel(ADC_PORT2_VOLTAGE_CH);
    adc_raw = ADC_Filter(2, adc_raw);
    voltage_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_voltage = voltage_adc * VOLTAGE_DIVIDER;
    
    adc_raw = ADC_Read_Channel(ADC_PORT2_CURRENT_CH);
    adc_raw = ADC_Filter(3, adc_raw);
    current_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_current = current_adc / (CURRENT_SENSE_RESISTOR * CURRENT_AMP_GAIN);
    
    actual_power = actual_voltage * actual_current;
    
    if(actual_voltage > VOLTAGE_THRESHOLD)
    {
        g_charge_ports[1].is_charging = (actual_current > CURRENT_THRESHOLD) ? 1 : 0;
        g_charge_ports[1].voltage = actual_voltage;
        g_charge_ports[1].current = actual_current;
        g_charge_ports[1].power = actual_power;
    }
    else
    {
        g_charge_ports[1].is_charging = 0;
        g_charge_ports[1].voltage = 0;
        g_charge_ports[1].current = 0;
        g_charge_ports[1].power = 0;
    }
    
    // 第3路：无线充电（WL）
    adc_raw = ADC_Read_Channel(ADC_PORT3_VOLTAGE_CH);
    adc_raw = ADC_Filter(4, adc_raw);
    voltage_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_voltage = voltage_adc * VOLTAGE_DIVIDER;
    
    adc_raw = ADC_Read_Channel(ADC_PORT3_CURRENT_CH);
    adc_raw = ADC_Filter(5, adc_raw);
    current_adc = (float)adc_raw / ADC_RESOLUTION * ADC_REF_VOLTAGE;
    actual_current = current_adc / (CURRENT_SENSE_RESISTOR * CURRENT_AMP_GAIN);
    
    actual_power = actual_voltage * actual_current;
    
    if(actual_voltage > VOLTAGE_THRESHOLD && actual_current > CURRENT_THRESHOLD)
    {
        g_charge_ports[2].is_charging = 1;
        g_charge_ports[2].voltage = actual_voltage;
        g_charge_ports[2].current = actual_current;
        g_charge_ports[2].power = actual_power;
    }
    else
    {
        g_charge_ports[2].is_charging = 0;
        g_charge_ports[2].voltage = 0;
        g_charge_ports[2].current = 0;
        g_charge_ports[2].power = 0;
    }
}
