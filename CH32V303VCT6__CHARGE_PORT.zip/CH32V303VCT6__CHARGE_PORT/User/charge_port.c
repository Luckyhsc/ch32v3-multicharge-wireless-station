#include "charge_port.h"
#include "lcd.h"
#include "lcd_init.h"
#include "debug.h"
#include <math.h>
#include <string.h>

// 前向声明
static u16 Power_ToY(float power);
void LCD_BeginWriteWindow(u16 x1,u16 y1,u16 x2,u16 y2);
void LCD_WritePixels(const u16 *pixels,u32 count);
void LCD_EndWriteWindow(void);

// 全局充电口数据（3路）
ChargePort_t g_charge_ports[3] = {
    {"A+C", 0, 0, 0, 0, PROTOCOL_NONE, PORT_TYPE_A},
    {"C1", 0, 0, 0, 0, PROTOCOL_NONE, PORT_TYPE_C},
    {"C2", 0, 0, 0, 0, PROTOCOL_NONE, PORT_TYPE_WIRELESS}
};
uint8_t g_port_count = 3;

// 测试用动态数据计数器
static uint32_t s_test_counter = 0;

// 页面状态
Page_t g_current_page = PAGE_MAIN;
int8_t g_selected_index = -1;

// 按键状态
static uint32_t s_key_left_press_time = 0;
static uint8_t s_key_left_long_pressed = 0;

// 刷新标志
static uint8_t s_need_refresh = 1;
static int8_t s_last_selected = -2;
static int8_t s_last_visible_start = -1;
static Page_t s_last_page = PAGE_MAIN;
static uint8_t s_last_charging[7] = {0};
static uint32_t s_detail_refresh_timer = 0;
static uint32_t s_main_refresh_timer = 0;
#define DETAIL_REFRESH_INTERVAL 100  // 分页面100ms刷新一次（与采样同步）
#define MAIN_REFRESH_INTERVAL 100    // 主页面100ms刷新一次（与采样同步）

// 分页面上次数据缓存（用于局部刷新）
static float s_last_voltage = 0;
static float s_last_current = 0;
static float s_last_power = 0;
static Protocol_t s_last_protocol = PROTOCOL_NONE;

// 功率采样相关
#define POWER_MAX         200    // 纵坐标最大功率值（瓦）
#define POWER_CLAMP       250    // 功率封顶值（超过200W后还能继续向上显示50W）
#define CHART_Y_TOP       10     // 图表区域顶部Y坐标
#define CHART_Y_BOTTOM    90     // 图表区域底部Y坐标（时间轴上方）
#define CHART_HEIGHT      (CHART_Y_BOTTOM - CHART_Y_TOP)  // 图表高度80像素
#define CHART_X_LEFT      18     // 图表区域左边界（向右移2像素）
#define CHART_X_RIGHT     218    // 图表区域右边界（向右移2像素）
#define CHART_WIDTH       (CHART_X_RIGHT - CHART_X_LEFT)  // 图表宽度200像素
#define SAMPLE_COUNT      200    // 采样点数量（200列 = 200像素）
#define SAMPLE_INTERVAL   100    // 采样间隔（毫秒），200点×100ms=20秒

// 功率采样缓冲区（每个端口一个环形缓冲区）
#define CHART_DATA_WIDTH  SAMPLE_COUNT
#define CHART_DATA_X_RIGHT (CHART_X_LEFT + CHART_DATA_WIDTH - 1)
#define MAIN_CHART_PIXEL_HEIGHT   (CHART_Y_BOTTOM - CHART_Y_TOP + 1)
#define DETAIL_CHART_PIXEL_HEIGHT (DETAIL_CHART_Y_BOTTOM - DETAIL_CHART_Y_TOP + 1)

static float s_power_samples[3][SAMPLE_COUNT] = {0};
static uint16_t s_sample_index = 0;      // 当前采样索引（0-199循环）
static uint16_t s_sample_count = 0;      // 已采样总数（用于判断是否填满）
static uint32_t s_sample_timer = 0;      // 采样定时器
static uint32_t s_chart_refresh_timer = 0; // 图表刷新定时器

// 电压/电流采样缓冲区（用于分页面图表）
static float s_voltage_samples[3][SAMPLE_COUNT] = {0};
static float s_current_samples[3][SAMPLE_COUNT] = {0};
static uint8_t s_chart_canvas[MAIN_CHART_PIXEL_HEIGHT][CHART_DATA_WIDTH] = {0};
static u16 s_chart_row_buffer[CHART_DATA_WIDTH];

// 电压/电流Y轴参数
#define VOLTAGE_MAX       20.0f  // 最大电压20V
#define CURRENT_MAX       12.0f  // 最大电流12A
#define VOLTAGE_CLAMP     25.0f  // 电压封顶值（超过20V后还能继续向上显示5V）
#define CURRENT_CLAMP     17.0f  // 电流封顶值（超过12A后还能继续向上显示5A）
#define DETAIL_CHART_Y_TOP    10
#define DETAIL_CHART_Y_BOTTOM 80
#define DETAIL_CHART_HEIGHT   (DETAIL_CHART_Y_BOTTOM - DETAIL_CHART_Y_TOP)

// 主页面功率缓存（用于检测变化）
static float s_last_main_power[3] = {0};

// 显示参数
#define DISPLAY_COUNT     3
#define LINE_HEIGHT       40   // 行距（可以自定义，不必等于字高）
#define Y_OFFSET          (LCD_H - LINE_HEIGHT * 3 - 10)  // 向下移到底部
#define FONT_SIZE         32

// 深色主题颜色定义
#define DARK_BG_COLOR     0x0000  // 纯黑背景
#define DARK_LINE_BG      0x0000  // 行背景与背景融合（纯黑）
#define DARK_SELECTED_BG  0x001F  // 选中行背景（蓝色）
#define DARK_TEXT_COLOR   0xFFFF  // 白色文字
#define DARK_LABEL_COLOR  0xFFE0  // 浅黄色标签（Vol/Cur/Pwr/Proto）
#define DARK_POWER_CHG    0x07E0  // 充电中功率（绿色）
#define DARK_POWER_IDLE   0x8430  // 空闲功率（灰色）
#define DARK_ICON_IDLE    0x4208  // 空闲图标（深灰偏黑）
#define DARK_ICON_CHG     0xFFE0  // 充电中图标（金黄色）
#define DARK_BORDER_SEL   0x7FFF  // 选中边框（青色）

// 时间轴颜色
#define TIME_AXIS_COLOR   0x8410  // 时间轴：浅灰色

// 分页面图表颜色
#define DETAIL_COLOR_POWER  0x07E0  // 功率：绿色
#define DETAIL_COLOR_VOLT   0xF81F  // 电压：紫色
#define DETAIL_COLOR_CURR   0xFD20  // 电流：橙色
#define DETAIL_SCALE_VOLT   0xF81F  // 电压刻度：紫色
#define DETAIL_SCALE_CURR   0xFD20  // 电流刻度：橙色

// 端口名称颜色（清新高级色系）
#define PORT_COLOR_A      0x867F  // A+C: 天蓝色
#define PORT_COLOR_C      0x9772  // C: 薄荷绿
#define PORT_COLOR_WL     0xFBD2  // WL: 樱花粉（淡粉色，更亮更柔和）

// 每行额外偏移（像素）
static const int8_t s_row_extra_offset[3] = {
    12,  // A+C行: 向下12像素
    0,   // C行:   不动
    -12  // WL行:  向上12像素
};

// 绘制圆角矩形（空心边框，支持线宽）
static void Draw_RoundRect(u16 x1, u16 y1, u16 x2, u16 y2, u8 r, u16 color, u8 width)
{
    u8 i;
    for(i = 0; i < width; i++)
    {
        u16 ox1 = x1 + i, oy1 = y1 + i;
        u16 ox2 = x2 - i, oy2 = y2 - i;
        
        // 四条直线
        LCD_DrawLine(ox1 + r, oy1, ox2 - r, oy1, color);       // 上边
        LCD_DrawLine(ox1 + r, oy2, ox2 - r, oy2, color);       // 下边
        LCD_DrawLine(ox1, oy1 + r, ox1, oy2 - r, color);       // 左边
        LCD_DrawLine(ox2, oy1 + r, ox2, oy2 - r, color);       // 右边
        
        // 四个圆角（用像素点绘制圆弧）
        u8 j;
        for(j = 0; j < r; j++)
        {
            // 计算圆弧上的点
            u8 dx = j, dy = r - j;
            if(dx * dx + dy * dy <= r * r)
            {
                // 左上角
                LCD_DrawPoint(ox1 + r - dx, oy1 + r - dy, color);
                LCD_DrawPoint(ox1 + r - dy, oy1 + r - dx, color);
                // 右上角
                LCD_DrawPoint(ox2 - r + dx, oy1 + r - dy, color);
                LCD_DrawPoint(ox2 - r + dy, oy1 + r - dx, color);
                // 左下角
                LCD_DrawPoint(ox1 + r - dx, oy2 - r + dy, color);
                LCD_DrawPoint(ox1 + r - dy, oy2 - r + dx, color);
                // 右下角
                LCD_DrawPoint(ox2 - r + dx, oy2 - r + dy, color);
                LCD_DrawPoint(ox2 - r + dy, oy2 - r + dx, color);
            }
        }
    }
}

// 绘制闪电图标（缩小一半，带圆形边框）
static void Draw_LightningIcon(u16 x, u16 y, u16 color)
{
    // 先画圆形边框
    Draw_Circle(x+8, y+8, 10, color);
    
    // 闪电形状：缩小一半，简洁Z字形（向左偏移1像素）
    // 上段：从右上到左下
    LCD_DrawLine(x+11, y+3, x+5, y+9, color);
    
    // 中段：从左下到右
    LCD_DrawLine(x+5, y+9, x+11, y+9, color);
    
    // 下段：从右上到左下
    LCD_DrawLine(x+11, y+9, x+5, y+15, color);
}

// 前向声明
static u16 Power_ToY(float power);
static u16 Voltage_ToY(float voltage);
static u16 Current_ToY(float current);
static void Clear_ChartCanvas(u16 height);
static void Draw_ChartGridRow(u16 y, u16 top, u16 bottom, uint8_t color_index);
static void Plot_ChartPoint(u16 x, u16 y, u16 top, u16 bottom, uint8_t color_index);
static void Flush_ChartCanvas(u16 x, u16 y, u16 height, const u16 *palette);
static void Render_MainChartToCanvas(void);
static void Render_DetailChartToCanvas(uint8_t port);

// 绘制主页面时间坐标轴（功率刻度）
static void Draw_TimeAxis(void)
{
    u16 axis_y = 100;
    u8 i;
    
    // 绘制水平轴线
    LCD_DrawLine(CHART_X_LEFT, axis_y, CHART_X_RIGHT, axis_y, TIME_AXIS_COLOR);
    
    // 绘制刻度标记（10格，每20像素一个刻度，向下延伸）
    for(i = 0; i <= 10; i++)
    {
        u16 x = CHART_X_LEFT + i * 20;
        LCD_DrawLine(x, axis_y, x, axis_y + 8, TIME_AXIS_COLOR);
    }
    
    // 标注时间
    LCD_ShowString(0, axis_y - 6, (u8*)"0s", TIME_AXIS_COLOR, DARK_BG_COLOR, 12, 0);
    LCD_ShowString(220, axis_y - 6, (u8*)"40s", TIME_AXIS_COLOR, DARK_BG_COLOR, 12, 0);
    
    // 左侧：功率刻度（白色）：0W、50W、100W、150W、200W
    u16 grid_color = 0x4208;
    u16 power_values[5] = {0, 50, 100, 150, 200};
    for(i = 0; i < 5; i++)
    {
        u16 y = Power_ToY((float)power_values[i]);
        LCD_DrawLine(CHART_X_LEFT, y, CHART_X_RIGHT, y, grid_color);
        char buf[8];
        if(power_values[i] == 0)
            sprintf(buf, "0W");
        else
            sprintf(buf, "%d", power_values[i]);
        LCD_ShowString(0, y - 6, (u8*)buf, TIME_AXIS_COLOR, DARK_BG_COLOR, 12, 0);
    }
}

// 绘制分页面时间坐标轴（电压/电流刻度）
static void Draw_DetailTimeAxis(void)
{
    u16 axis_y = 100;
    u8 i;
    
    // 绘制水平轴线
    LCD_DrawLine(CHART_X_LEFT, axis_y, CHART_X_RIGHT, axis_y, TIME_AXIS_COLOR);
    
    // 绘制刻度标记（10格，每20像素一个刻度，向下延伸）
    for(i = 0; i <= 10; i++)
    {
        u16 x = CHART_X_LEFT + i * 20;
        LCD_DrawLine(x, axis_y, x, axis_y + 8, TIME_AXIS_COLOR);
    }
    
    // 标注时间
    LCD_ShowString(0, axis_y - 6, (u8*)"0s", TIME_AXIS_COLOR, DARK_BG_COLOR, 12, 0);
    LCD_ShowString(220, axis_y - 6, (u8*)"40s", TIME_AXIS_COLOR, DARK_BG_COLOR, 12, 0);
    
    // 左侧：电压刻度（淡紫色）：0V、5V、10V、15V、20V
    u16 grid_color = 0x4208;
    u16 volt_values[5] = {0, 5, 10, 15, 20};
    for(i = 0; i < 5; i++)
    {
        u16 y = Voltage_ToY((float)volt_values[i]);
        LCD_DrawLine(CHART_X_LEFT, y, CHART_X_RIGHT, y, grid_color);
        char buf[8];
        if(volt_values[i] == 0)
            sprintf(buf, "0V");
        else
            sprintf(buf, "%d", volt_values[i]);
        LCD_ShowString(0, y - 6, (u8*)buf, DETAIL_SCALE_VOLT, DARK_BG_COLOR, 12, 0);
    }
    
    // 右侧：电流刻度（浅橙色）：0A、3A、6A、9A、12A
    u16 curr_values[5] = {0, 3, 6, 9, 12};
    for(i = 0; i < 5; i++)
    {
        u16 y = Current_ToY((float)curr_values[i]);
        char buf[8];
        if(curr_values[i] == 0)
            sprintf(buf, "0A");
        else
            sprintf(buf, "%d", curr_values[i]);
        LCD_ShowString(CHART_X_RIGHT + 2, y - 6, (u8*)buf, DETAIL_SCALE_CURR, DARK_BG_COLOR, 12, 0);
    }
}

// 功率值映射到Y坐标（超过200W后继续向上，250W时卡在Y=5）
static u16 Power_ToY(float power)
{
    if(power <= 0)
        return CHART_Y_BOTTOM;
    
    u16 y_offset = (u16)((power * CHART_HEIGHT) / POWER_MAX);
    int y = CHART_Y_BOTTOM - y_offset;
    if(y < CHART_Y_TOP - 5)
        return CHART_Y_TOP - 5;
    return (u16)y;
}

// 电压映射到Y坐标（超过20V后继续向上，25V时卡在Y=5）
static u16 Voltage_ToY(float voltage)
{
    if(voltage <= 0)
        return DETAIL_CHART_Y_BOTTOM;
    
    u16 y_offset = (u16)((voltage * DETAIL_CHART_HEIGHT) / VOLTAGE_MAX);
    int y = DETAIL_CHART_Y_BOTTOM - y_offset;
    if(y < DETAIL_CHART_Y_TOP - 5)
        return DETAIL_CHART_Y_TOP - 5;
    return (u16)y;
}

// 电流映射到Y坐标（超过12A后继续向上，17A时卡在Y=5）
static u16 Current_ToY(float current)
{
    if(current <= 0)
        return DETAIL_CHART_Y_BOTTOM;
    
    u16 y_offset = (u16)((current * DETAIL_CHART_HEIGHT) / CURRENT_MAX);
    int y = DETAIL_CHART_Y_BOTTOM - y_offset;
    if(y < DETAIL_CHART_Y_TOP - 5)
        return DETAIL_CHART_Y_TOP - 5;
    return (u16)y;
}

static void Clear_ChartCanvas(u16 height)
{
    memset(s_chart_canvas, 0, (size_t)height * CHART_DATA_WIDTH);
}

static void Draw_ChartGridRow(u16 y, u16 top, u16 bottom, uint8_t color_index)
{
    if(y < top || y > bottom)
        return;

    memset(s_chart_canvas[y - top], color_index, CHART_DATA_WIDTH);
}

static void Plot_ChartPoint(u16 x, u16 y, u16 top, u16 bottom, uint8_t color_index)
{
    if(x >= CHART_DATA_WIDTH)
        return;
    if(y < top || y > bottom)
        return;

    s_chart_canvas[y - top][x] = color_index;
}

static void Flush_ChartCanvas(u16 x, u16 y, u16 height, const u16 *palette)
{
    u16 row, col;

    LCD_BeginWriteWindow(x, y, x + CHART_DATA_WIDTH - 1, y + height - 1);
    for(row = 0; row < height; row++)
    {
        for(col = 0; col < CHART_DATA_WIDTH; col++)
        {
            s_chart_row_buffer[col] = palette[s_chart_canvas[row][col]];
        }
        LCD_WritePixels(s_chart_row_buffer, CHART_DATA_WIDTH);
    }
    LCD_EndWriteWindow();
}

static void Render_MainChartToCanvas(void)
{
    static const u16 power_values[5] = {0, 50, 100, 150, 200};
    static const u16 palette[] = {DARK_BG_COLOR, 0x4208, PORT_COLOR_A, PORT_COLOR_C, PORT_COLOR_WL};
    u16 i, y;
    uint8_t port;

    Clear_ChartCanvas(MAIN_CHART_PIXEL_HEIGHT);

    for(i = 0; i < 5; i++)
    {
        y = Power_ToY((float)power_values[i]);
        Draw_ChartGridRow(y, CHART_Y_TOP, CHART_Y_BOTTOM, 1);
    }

    if(s_sample_count < SAMPLE_COUNT)
    {
        for(i = 0; i < s_sample_count; i++)
        {
            for(port = 0; port < 3; port++)
            {
                y = Power_ToY(s_power_samples[port][i]);
                Plot_ChartPoint(i, y, CHART_Y_TOP, CHART_Y_BOTTOM, (uint8_t)(2 + port));
            }
        }
    }
    else
    {
        for(i = 0; i < SAMPLE_COUNT; i++)
        {
            u16 idx = (s_sample_index + i) % SAMPLE_COUNT;
            for(port = 0; port < 3; port++)
            {
                y = Power_ToY(s_power_samples[port][idx]);
                Plot_ChartPoint(i, y, CHART_Y_TOP, CHART_Y_BOTTOM, (uint8_t)(2 + port));
            }
        }
    }

    Flush_ChartCanvas(CHART_X_LEFT, CHART_Y_TOP, MAIN_CHART_PIXEL_HEIGHT, palette);
}

static void Render_DetailChartToCanvas(uint8_t port)
{
    static const u16 volt_values[5] = {0, 5, 10, 15, 20};
    static const u16 palette[] = {DARK_BG_COLOR, 0x4208, DETAIL_COLOR_VOLT, DETAIL_COLOR_CURR};
    u16 i, y;

    Clear_ChartCanvas(DETAIL_CHART_PIXEL_HEIGHT);

    for(i = 0; i < 5; i++)
    {
        y = Voltage_ToY((float)volt_values[i]);
        Draw_ChartGridRow(y, DETAIL_CHART_Y_TOP, DETAIL_CHART_Y_BOTTOM, 1);
    }

    if(s_sample_count < SAMPLE_COUNT)
    {
        for(i = 0; i < s_sample_count; i++)
        {
            y = Voltage_ToY(s_voltage_samples[port][i]);
            Plot_ChartPoint(i, y, DETAIL_CHART_Y_TOP, DETAIL_CHART_Y_BOTTOM, 2);

            y = Current_ToY(s_current_samples[port][i]);
            Plot_ChartPoint(i, y, DETAIL_CHART_Y_TOP, DETAIL_CHART_Y_BOTTOM, 3);
        }
    }
    else
    {
        for(i = 0; i < SAMPLE_COUNT; i++)
        {
            u16 idx = (s_sample_index + i) % SAMPLE_COUNT;

            y = Voltage_ToY(s_voltage_samples[port][idx]);
            Plot_ChartPoint(i, y, DETAIL_CHART_Y_TOP, DETAIL_CHART_Y_BOTTOM, 2);

            y = Current_ToY(s_current_samples[port][idx]);
            Plot_ChartPoint(i, y, DETAIL_CHART_Y_TOP, DETAIL_CHART_Y_BOTTOM, 3);
        }
    }

    Flush_ChartCanvas(CHART_X_LEFT, DETAIL_CHART_Y_TOP, DETAIL_CHART_PIXEL_HEIGHT, palette);
}

// 采样当前功率值（只存数据，不画图）
static void Sample_Power(void)
{
    u8 port;
    
    // 读取实际端口数据存入采样缓冲区
    for(port = 0; port < 3; port++)
    {
        s_power_samples[port][s_sample_index] = (u16)g_charge_ports[port].power;
        s_voltage_samples[port][s_sample_index] = g_charge_ports[port].voltage;
        s_current_samples[port][s_sample_index] = g_charge_ports[port].current;
    }
    
    // 更新采样索引（环形缓冲）
    s_sample_index++;
    if(s_sample_index >= SAMPLE_COUNT)
        s_sample_index = 0;
    
    // 记录已采样总数（最多到SAMPLE_COUNT）
    if(s_sample_count < SAMPLE_COUNT)
        s_sample_count++;
}

// 绘制功率图表
static void Draw_PowerChart(void)
{
    u16 i, x, y;
    u16 colors[3] = {PORT_COLOR_A, PORT_COLOR_C, PORT_COLOR_WL};
    
    if(s_sample_count == 0)
        return;  // 没有数据，不画
    
    if(s_sample_count < SAMPLE_COUNT)
    {
        // 未满（前20秒）：绘制所有已采集的点（从左到右）
        for(i = 0; i < s_sample_count; i++)
        {
            x = CHART_X_LEFT + i;
            
            for(u8 port = 0; port < 3; port++)
            {
                y = Power_ToY(s_power_samples[port][i]);
                LCD_DrawPoint(x, y, colors[port]);
            }
        }
    }
    else
    {
        // 已满（滚动模式）：先清屏再重绘所有点
        LCD_Fill(CHART_X_LEFT, CHART_Y_TOP, CHART_X_RIGHT + 1, CHART_Y_BOTTOM + 5, DARK_BG_COLOR);
        
        // 重绘网格线（清屏后网格线也被清掉了）
        u16 grid_color = 0x4208;
        u16 power_values[5] = {0, 50, 100, 150, 200};
        u8 j;
        for(j = 0; j < 5; j++)
        {
            u16 gy = Power_ToY(power_values[j]);
            LCD_DrawLine(CHART_X_LEFT, gy, CHART_X_RIGHT, gy, grid_color);
        }
        
        // 从右往左绘制（先画右边最新数据，再画左边旧数据）
        for(i = 0; i < SAMPLE_COUNT; i++)
        {
            u16 idx = (s_sample_index + SAMPLE_COUNT - 1 - i) % SAMPLE_COUNT;
            x = CHART_X_RIGHT - i;
            
            for(u8 port = 0; port < 3; port++)
            {
                y = Power_ToY(s_power_samples[port][idx]);
                LCD_DrawPoint(x, y, colors[port]);
            }
        }
    }
}

// 协议名称转换
static const char* Protocol_ToString(Protocol_t protocol)
{
    switch(protocol)
    {
        case PROTOCOL_NONE:     return "None";
        case PROTOCOL_QC20:     return "QC2.0";
        case PROTOCOL_QC30:     return "QC3.0";
        case PROTOCOL_PD:       return "PD";
        case PROTOCOL_AFC:      return "AFC";
        case PROTOCOL_FCP:      return "FCP";
        case PROTOCOL_WIRELESS: return "Wireless";
        default:                return "Unknown";
    }
}

// 充电口初始化
void ChargePort_Init(void)
{
    uint8_t i;
    // 强制清零所有充电口数据
    for(i = 0; i < 7; i++)
    {
        g_charge_ports[i].is_charging = 0;
        g_charge_ports[i].voltage = 0;
        g_charge_ports[i].current = 0;
        g_charge_ports[i].power = 0;
        g_charge_ports[i].protocol = PROTOCOL_NONE;
    }
}

// 更新充电口数据
void ChargePort_Update(void)
{
    uint8_t i;
    
    for(i = 0; i < g_port_count; i++)
    {
        if(g_charge_ports[i].is_charging != s_last_charging[i])
        {
            s_need_refresh = 1;
            s_last_charging[i] = g_charge_ports[i].is_charging;
        }
    }
}

// 按键初始化
void Key_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = KEY_LEFT_PIN | KEY_RIGHT_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(KEY_LEFT_PORT, &GPIO_InitStructure);
}

// 绘制单行（主页只显示接口名称和功率）
static void Draw_MainLine(uint8_t index, uint8_t y, uint8_t is_selected)
{
    uint16_t bg_color, text_color, power_color;
    char buf[32];
    int int_part, dec_part;
    
    if(index == 0)
        text_color = PORT_COLOR_A;
    else if(index == 1)
        text_color = PORT_COLOR_C;
    else
        text_color = PORT_COLOR_WL;
    
    bg_color = DARK_BG_COLOR;
    
    if(is_selected)
    {
        power_color = DARK_TEXT_COLOR;
    }
    else
    {
        power_color = g_charge_ports[index].is_charging ? DARK_POWER_CHG : DARK_POWER_IDLE;
    }
    
    // 绘制闪电图标（充电中用金黄色，空闲用深灰色）
    u16 icon_color = g_charge_ports[index].is_charging ? DARK_ICON_CHG : DARK_ICON_IDLE;
    Draw_LightningIcon(15, y + 18, icon_color);
    
    LCD_ShowString(45, y + 10, (u8*)g_charge_ports[index].name, text_color, bg_color, FONT_SIZE, 0);
    
    if(g_charge_ports[index].is_charging)
    {
        int_part = (int)g_charge_ports[index].power;
        dec_part = (int)(g_charge_ports[index].power * 100) % 100;
        sprintf(buf, "%d.%02dW", int_part, dec_part);
    }
    else
    {
        strcpy(buf, "0.00W");
    }
    
    LCD_ShowString(114, y + 10, (u8*)buf, power_color, bg_color, FONT_SIZE, 0);
    
    // 选中时绘制青色圆角边框（位置下移与文字对齐，线宽2像素）
    if(is_selected)
    {
        Draw_RoundRect(8, y + 6, LCD_W - 8, y + LINE_HEIGHT + 6, 8, DARK_BORDER_SEL, 2);
    }
    else
    {
        // 未选中时清除边框区域（用黑色覆盖旧边框，扩大范围确保完全清除）
        LCD_Fill(4, y + 2, 20, y + 18, DARK_BG_COLOR);       // 左上角
        LCD_Fill(LCD_W - 20, y + 2, LCD_W - 4, y + 18, DARK_BG_COLOR);  // 右上角
        LCD_Fill(4, y + LINE_HEIGHT - 6, 20, y + LINE_HEIGHT + 10, DARK_BG_COLOR);  // 左下角
        LCD_Fill(LCD_W - 20, y + LINE_HEIGHT - 6, LCD_W - 4, y + LINE_HEIGHT + 10, DARK_BG_COLOR);  // 右下角
        LCD_Fill(6, y + 6, LCD_W - 4, y + 10, DARK_BG_COLOR);  // 上边
        LCD_Fill(6, y + LINE_HEIGHT + 2, LCD_W - 4, y + LINE_HEIGHT + 8, DARK_BG_COLOR);  // 下边
        LCD_Fill(4, y + 10, 10, y + LINE_HEIGHT + 2, DARK_BG_COLOR);  // 左边
        LCD_Fill(LCD_W - 10, y + 10, LCD_W - 4, y + LINE_HEIGHT + 2, DARK_BG_COLOR);  // 右边
    }
}

// 刷新主页面功率数值（只刷新功率，不整页重绘）
static void Draw_MainPage_Update(void)
{
    uint8_t i;
    char buf[32];
    int int_part, dec_part;
    
    // 图表刷新：未满时增量添加新点，已满时全量刷新
    Draw_PowerChart();
    
    for(i = 0; i < g_port_count; i++)
    {
        if(g_charge_ports[i].power != s_last_main_power[i])
        {
            uint8_t y = Y_OFFSET + i * LINE_HEIGHT + s_row_extra_offset[i];
            uint16_t bg_color = DARK_BG_COLOR;  // 统一用黑色背景
            uint16_t power_color;
            
            if(i == g_selected_index)
                power_color = DARK_TEXT_COLOR;
            else if(g_charge_ports[i].is_charging)
                power_color = DARK_POWER_CHG;
            else
                power_color = DARK_POWER_IDLE;
            
            if(g_charge_ports[i].is_charging)
            {
                int_part = (int)g_charge_ports[i].power;
                dec_part = (int)(g_charge_ports[i].power * 100) % 100;
                sprintf(buf, "%d.%02dW", int_part, dec_part);
            }
            else
            {
                strcpy(buf, "0.00W");
            }
            
            LCD_ShowString(114, y + 10, (u8*)buf, power_color, bg_color, FONT_SIZE, 0);
            s_last_main_power[i] = g_charge_ports[i].power;
        }
    }
}

// 绘制主页面（3路不需要滚动）
static void Draw_MainPage(void)
{
    uint8_t i;
    
    LCD_Fill(0, 0, LCD_W - 1, LCD_H - 1, DARK_BG_COLOR);
    
    // 绘制时间坐标轴
    Draw_TimeAxis();
    
    // 重绘所有已采集的功率点（页面刷新时）
    Draw_PowerChart();
    
    for(i = 0; i < g_port_count; i++)
    {
        uint8_t y = Y_OFFSET + i * LINE_HEIGHT + s_row_extra_offset[i];
        Draw_MainLine(i, y, (i == g_selected_index));
        s_last_main_power[i] = g_charge_ports[i].power;
    }
    
    s_last_selected = g_selected_index;
    s_last_page = g_current_page;
}

// 绘制分页面图表（电压+电流，完全复用主页面逻辑）
static void Draw_DetailChart(void)
{
    u16 i, x, y;
    u8 port;
    
    if(g_selected_index < 0) return;
    if(s_sample_count == 0) return;
    
    port = g_selected_index;
    
    if(s_sample_count < SAMPLE_COUNT)
    {
        // 未满（前20秒）：绘制所有已采集的点（从左到右）
        for(i = 0; i < s_sample_count; i++)
        {
            x = CHART_X_LEFT + i;
            
            // 画电压点（橙色）
            y = Voltage_ToY(s_voltage_samples[port][i]);
            LCD_DrawPoint(x, y, DETAIL_COLOR_VOLT);
            
            // 画电流点（紫色）
            y = Current_ToY(s_current_samples[port][i]);
            LCD_DrawPoint(x, y, DETAIL_COLOR_CURR);
        }
    }
    else
    {
        // 已满（滚动模式）：先清屏再重绘所有点
        LCD_Fill(CHART_X_LEFT, CHART_Y_TOP, CHART_X_RIGHT + 1, CHART_Y_BOTTOM + 5, DARK_BG_COLOR);
        
        // 重绘电压网格线（清屏后网格线也被清掉了）
        u16 grid_color = 0x4208;
        u16 volt_values[5] = {0, 5, 10, 15, 20};
        u8 j;
        for(j = 0; j < 5; j++)
        {
            u16 gy = Voltage_ToY((float)volt_values[j]);
            LCD_DrawLine(CHART_X_LEFT, gy, CHART_X_RIGHT, gy, grid_color);
        }
        
        // 从右往左绘制（先画右边最新数据，再画左边旧数据）
        for(i = 0; i < SAMPLE_COUNT; i++)
        {
            u16 idx = (s_sample_index + SAMPLE_COUNT - 1 - i) % SAMPLE_COUNT;
            x = CHART_X_RIGHT - i;
            
            // 画电压点（橙色）
            y = Voltage_ToY(s_voltage_samples[port][idx]);
            LCD_DrawPoint(x, y, DETAIL_COLOR_VOLT);
            
            // 画电流点（紫色）
            y = Current_ToY(s_current_samples[port][idx]);
            LCD_DrawPoint(x, y, DETAIL_COLOR_CURR);
        }
    }
}

// 绘制分页面
static void Draw_DetailPage(void)
{
    uint8_t y;
    char buf[32];
    int int_part, dec_part;
    uint16_t label_color = DARK_LABEL_COLOR;
    uint16_t bg_color = DARK_BG_COLOR;
    const char *port_short_name;
    
    if(g_selected_index < 0)
    {
        g_current_page = PAGE_MAIN;
        s_need_refresh = 1;
        return;
    }
    
    LCD_Fill(0, 0, LCD_W - 1, LCD_H - 1, DARK_BG_COLOR);
    
    // 端口短名称（右下角，64号大字体）
    switch(g_selected_index)
    {
        case 0: port_short_name = "A/C"; break;   // A+C端口
        case 1: port_short_name = "C1"; break;     // C1端口
        case 2: port_short_name = "C2"; break;    // C2端口
        default: port_short_name = g_charge_ports[g_selected_index].name; break;
    }
    LCD_ShowString(10, 160, (u8*)port_short_name, 0x8430, bg_color, 32, 0);
    
    // 绘制时间坐标轴（电压/电流刻度）
    Draw_DetailTimeAxis();
    
    // 绘制电压/电流图表（上半部分）
    Draw_DetailChart();
    
    // 底部四行（从下往上排列，行距25，整体右移）
    y = LCD_H - 110;
    
    // 电压
    LCD_ShowString(75, y, (u8*)"Vol:", label_color, bg_color, 24, 0);
    int_part = (int)g_charge_ports[g_selected_index].voltage;
    dec_part = (int)(g_charge_ports[g_selected_index].voltage * 100) % 100;
    sprintf(buf, "%d.%02dV", int_part, dec_part);
    LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_VOLT, bg_color, 24, 0);
    y += 25;
    
    // 电流
    LCD_ShowString(75, y, (u8*)"Cur:", label_color, bg_color, 24, 0);
    int_part = (int)g_charge_ports[g_selected_index].current;
    dec_part = (int)(g_charge_ports[g_selected_index].current * 100) % 100;
    sprintf(buf, "%d.%02dA", int_part, dec_part);
    LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_CURR, bg_color, 24, 0);
    y += 25;
    
    // 功率
    LCD_ShowString(75, y, (u8*)"Pwr:", label_color, bg_color, 24, 0);
    int_part = (int)g_charge_ports[g_selected_index].power;
    dec_part = (int)(g_charge_ports[g_selected_index].power * 100) % 100;
    sprintf(buf, "%d.%02dW", int_part, dec_part);
    LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_POWER, bg_color, 24, 0);
    y += 25;
    
    // 协议
    LCD_ShowString(75, y, (u8*)"Proto:", label_color, bg_color, 24, 0);
    LCD_ShowString(155, y, (u8*)Protocol_ToString(g_charge_ports[g_selected_index].protocol), 
                   DARK_TEXT_COLOR, bg_color, 24, 0);
    
    // 更新缓存
    s_last_voltage = g_charge_ports[g_selected_index].voltage;
    s_last_current = g_charge_ports[g_selected_index].current;
    s_last_power = g_charge_ports[g_selected_index].power;
    s_last_protocol = g_charge_ports[g_selected_index].protocol;
}

// 分页面局部刷新（只刷新数值）
static void Draw_DetailPage_Update(void)
{
    uint8_t y = LCD_H - 110;
    char buf[32];
    int int_part, dec_part;
    uint16_t bg_color = DARK_BG_COLOR;
    
    if(g_selected_index < 0) return;
    
    // 刷新图表（增量绘制）
    Draw_DetailChart();
    
    // 刷新电压（先清除旧值区域）
    if(g_charge_ports[g_selected_index].voltage != s_last_voltage)
    {
        LCD_Fill(145, y, LCD_W - 10, y + 24, bg_color);
        int_part = (int)g_charge_ports[g_selected_index].voltage;
        dec_part = (int)(g_charge_ports[g_selected_index].voltage * 100) % 100;
        sprintf(buf, "%d.%02dV", int_part, dec_part);
        LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_VOLT, bg_color, 24, 0);
        s_last_voltage = g_charge_ports[g_selected_index].voltage;
    }
    y += 25;
    
    // 刷新电流（先清除旧值区域）
    if(g_charge_ports[g_selected_index].current != s_last_current)
    {
        LCD_Fill(145, y, LCD_W - 10, y + 24, bg_color);
        int_part = (int)g_charge_ports[g_selected_index].current;
        dec_part = (int)(g_charge_ports[g_selected_index].current * 100) % 100;
        sprintf(buf, "%d.%02dA", int_part, dec_part);
        LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_CURR, bg_color, 24, 0);
        s_last_current = g_charge_ports[g_selected_index].current;
    }
    y += 25;
    
    // 刷新功率（先清除旧值区域）
    if(g_charge_ports[g_selected_index].power != s_last_power)
    {
        LCD_Fill(145, y, LCD_W - 10, y + 24, bg_color);
        int_part = (int)g_charge_ports[g_selected_index].power;
        dec_part = (int)(g_charge_ports[g_selected_index].power * 100) % 100;
        sprintf(buf, "%d.%02dW", int_part, dec_part);
        LCD_ShowString(145, y, (u8*)buf, DETAIL_COLOR_POWER, bg_color, 24, 0);
        s_last_power = g_charge_ports[g_selected_index].power;
    }
    y += 25;
    
    // 刷新协议（先清除旧值区域）
    if(g_charge_ports[g_selected_index].protocol != s_last_protocol)
    {
        LCD_Fill(155, y, LCD_W - 10, y + 24, bg_color);
        LCD_ShowString(155, y, (u8*)Protocol_ToString(g_charge_ports[g_selected_index].protocol), 
                       DARK_TEXT_COLOR, bg_color, 24, 0);
        s_last_protocol = g_charge_ports[g_selected_index].protocol;
    }
}

// 刷新主页面选中状态（只刷新两行，不整页重绘）
static void Draw_MainPage_SelectionChange(void)
{
    uint8_t old_idx, new_idx;
    uint8_t y;
    
    if(s_last_selected < 0 && g_selected_index < 0)
        return;
    
    // 刷新旧选中行（变为未选中）
    if(s_last_selected >= 0 && s_last_selected < g_port_count)
    {
        old_idx = s_last_selected;
        y = Y_OFFSET + old_idx * LINE_HEIGHT + s_row_extra_offset[old_idx];
        Draw_MainLine(old_idx, y, 0);
        s_last_main_power[old_idx] = g_charge_ports[old_idx].power;
    }
    
    // 刷新新选中行（变为选中）
    if(g_selected_index >= 0 && g_selected_index < g_port_count)
    {
        new_idx = g_selected_index;
        y = Y_OFFSET + new_idx * LINE_HEIGHT + s_row_extra_offset[new_idx];
        Draw_MainLine(new_idx, y, 1);
        s_last_main_power[new_idx] = g_charge_ports[new_idx].power;
    }
    
    s_last_selected = g_selected_index;
}

// 刷新显示
void ChargePort_Display(void)
{
    uint8_t need_draw = 0;
    
    // 功率采样（每 100ms 一次）- 所有页面都执行
    s_sample_timer += 50;
    if(s_sample_timer >= SAMPLE_INTERVAL)
    {
        s_sample_timer = 0;
        Sample_Power();
    }
    
    if(g_current_page == PAGE_DETAIL)
    {
        s_detail_refresh_timer += 50;
        if(s_detail_refresh_timer >= DETAIL_REFRESH_INTERVAL)
        {
            s_detail_refresh_timer = 0;
            Draw_DetailPage_Update();
            return;
        }
    }
    else if(g_current_page == PAGE_MAIN)
    {
        s_main_refresh_timer += 50;
        if(s_main_refresh_timer >= MAIN_REFRESH_INTERVAL)
        {
            s_main_refresh_timer = 0;
            Draw_MainPage_Update();
            // 注意：不再 return，让采样代码继续执行
        }
    }
    
    if(s_need_refresh || s_last_page != g_current_page || s_last_selected != g_selected_index)
        need_draw = 1;
    
    if(need_draw)
    {
        if(g_current_page == PAGE_MAIN)
        {
            if(s_last_page != g_current_page || s_last_selected == -2)
            {
                Draw_MainPage();
            }
            else if(s_last_selected != g_selected_index)
            {
                Draw_MainPage_SelectionChange();
            }
        }
        else
        {
            Draw_DetailPage();
        }
        
        s_need_refresh = 0;
        s_last_page = g_current_page;
        s_last_selected = g_selected_index;
    }
}

// 按键扫描
void Key_Scan(void)
{
    static uint8_t key_left_last = 1;
    static uint8_t key_right_last = 1;
    
    uint8_t key_left = KEY_LEFT_READ();
    uint8_t key_right = KEY_RIGHT_READ();
    
    // 左键处理
    if(key_left == 0 && key_left_last == 1)
    {
        s_key_left_press_time = 0;
        s_key_left_long_pressed = 0;
    }
    else if(key_left == 0)
    {
        s_key_left_press_time += 50;
        if(s_key_left_press_time >= LONG_PRESS_TIME && !s_key_left_long_pressed)
        {
            s_key_left_long_pressed = 1;
            if(g_current_page == PAGE_DETAIL)
            {
                g_current_page = PAGE_MAIN;
                g_selected_index = -1;
                s_need_refresh = 1;
                s_last_selected = -2;
            }
        }
    }
    else if(key_left == 1 && key_left_last == 0)
    {
        if(!s_key_left_long_pressed)
        {
            if(g_current_page == PAGE_MAIN)
            {
                if(g_selected_index == -1)
                    g_selected_index = 0;
                else if(g_selected_index < (int8_t)g_port_count - 1)
                    g_selected_index++;
                else
                    g_selected_index = 0;
                s_need_refresh = 1;
            }
        }
    }
    key_left_last = key_left;
    
    // 右键处理
    if(key_right == 0 && key_right_last == 1)
    {
        if(g_current_page == PAGE_MAIN && g_selected_index >= 0)
        {
            g_current_page = PAGE_DETAIL;
            s_need_refresh = 1;
        }
        else if(g_current_page == PAGE_DETAIL)
        {
            g_current_page = PAGE_MAIN;
            g_selected_index = -1;
            s_need_refresh = 1;
            s_last_selected = -2;
        }
    }
    key_right_last = key_right;
}
