#include "debug.h"
#include "sys.h"
#include "lcd_init.h"
#include "lcd.h"
#include "charge_port.h"
#include "adc.h"

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SystemCoreClockUpdate();
	Delay_Init();
	USART_Printf_Init(115200);
	
	printf("SystemClk:%d\r\n", SystemCoreClock);
	printf("ChipID:%08x\r\n", DBGMCU_GetCHIPID());
	printf("Charging Station LCD Init\r\n");
	
	LCD_Init();
	LCD_Fill(0, 0, LCD_W - 1, LCD_H - 1, 0xF7FE);
	
	ChargePort_Init();
	Key_Init();
	ADC_Init_All();
	
	while(1)
	{
		Key_Scan();
		ADC_Update_All();
		ChargePort_Display();
		Delay_Ms(50);
	}
}
