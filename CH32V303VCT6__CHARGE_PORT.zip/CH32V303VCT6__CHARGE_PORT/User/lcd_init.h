#ifndef __LCD_INIT_H
#define __LCD_INIT_H

#include "sys.h"

#define USE_HORIZONTAL 2

#define LCD_W 240
#define LCD_H 240

#define LCD_RES_Clr()  GPIO_ResetBits(GPIOA, GPIO_Pin_2)
#define LCD_RES_Set()  GPIO_SetBits(GPIOA, GPIO_Pin_2)

#define LCD_DC_Clr()   GPIO_ResetBits(GPIOA, GPIO_Pin_3)
#define LCD_DC_Set()   GPIO_SetBits(GPIOA, GPIO_Pin_3)

#define LCD_CS_Clr()   GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define LCD_CS_Set()   GPIO_SetBits(GPIOA, GPIO_Pin_4)

#define LCD_BLK_Clr()  GPIO_ResetBits(GPIOB, GPIO_Pin_5)
#define LCD_BLK_Set()  GPIO_SetBits(GPIOB, GPIO_Pin_5)

void LCD_GPIO_Init(void);
void SPI1_Init(void);
void SPI1_SendByte(u8 dat);
void SPI1_WaitForTransferComplete(void);
void LCD_WR_DATA8(u8 dat);
void LCD_WR_DATA(u16 dat);
void LCD_WR_REG(u8 dat);
void LCD_Address_Set(u16 x1, u16 y1, u16 x2, u16 y2);
void LCD_Init(void);

#endif
